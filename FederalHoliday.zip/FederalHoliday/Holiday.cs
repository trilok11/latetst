﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FederalHoliday
{
    //TFS 3032 (NET Project)

    //TFS 3032 (NET Project)
    public class Holiday
    {


        public bool IsHoliday { get; set; }
        public string HolidayName { get; set; }

        private int HolidayMonth { get; set; }
        private int HolidayDay { get; set; }
        private int HolidayYear { get; set; }
        private string HolidayDayOfWeek { get; set; }
        private DateTime DateToCheck { get; set; }

        public Holiday()
        {
        }

        public Holiday(DateTime CheckHolidayDate)
        {
            TimeSpan ts = new TimeSpan(00, 00, 0);
            CheckHolidayDate = CheckHolidayDate.Date + ts;
            IsFederalHoliday(CheckHolidayDate);
        }

        public bool IsFederalHoliday(DateTime CheckHolidayDate)
        {
            IsHoliday = false;
            ParseDate(CheckHolidayDate);

            if (IsNewYears()) { return IsHoliday; }
            if (IsMartinLutherKing()) { return IsHoliday; }
            if (IsPresidentsDay()) { return IsHoliday; }
            if (IsMemorialDay()) { return IsHoliday; }
            if (IsIndependenceDay()) { return IsHoliday; }
            if (IsLaborDay()) { return IsHoliday; }
            if (IsColumbusDay()) { return IsHoliday; }
            if (IsVeteransDay()) { return IsHoliday; }
            if (IsThanksgivingDay()) { return IsHoliday; }
            if (IsChristmas()) { return IsHoliday; }

            return IsHoliday;
        }

        private bool IsNewYears()
        {

            if (HolidayMonth == 12 && HolidayDay == 31 && DateToCheck.DayOfWeek == DayOfWeek.Friday)
            {
                IsHoliday = true;
                HolidayName = @"New Year's Day";
                return IsHoliday;
            }

            if (HolidayMonth == 1 && HolidayDay == 2 && DateToCheck.DayOfWeek == DayOfWeek.Monday)
            {
                IsHoliday = true;
                HolidayName = @"New Year's Day";
                return IsHoliday;
            }

            if (HolidayDay == 1 && HolidayMonth == 1)
            {
                IsHoliday = true;
                HolidayName = @"New Year's Day";
            }

            return IsHoliday;
        }

        private bool IsMartinLutherKing()
        {
            //Birthday of Martin Luther King, Jr. (Third Monday in January).
            if (HolidayMonth == 1)
            {
                if (DateToCheck.DayOfWeek == DayOfWeek.Monday && DateToCheck.Day > 14 && DateToCheck.Day < 22)
                {
                    IsHoliday = true;
                    HolidayName = @"Martin Luther King, Jr. Day";
                }
            }

            return IsHoliday;
        }

        private bool IsPresidentsDay()
        {
            //Washington's Birthday (Third Monday in February).
            if (HolidayMonth == 2)
            {
                if (DateToCheck.DayOfWeek == DayOfWeek.Monday && DateToCheck.Day > 14 && DateToCheck.Day < 22)
                {
                    IsHoliday = true;
                    HolidayName = @"Presidents Day";
                }
            }

            return IsHoliday;
        }

        private bool IsMemorialDay()
        {
            //Memorial Day (Last Monday in May).
            if (HolidayMonth == 5)
            {
                if (DateToCheck.DayOfWeek == DayOfWeek.Monday)
                {
                    DateTime workDate = Convert.ToDateTime("6/1/" + HolidayYear.ToString().Trim());

                    for (int i = 1; i < 8; i++)
                    {
                        if (workDate.AddDays(i * -1).DayOfWeek == DayOfWeek.Monday)
                        {
                            if (workDate.AddDays(i * -1).Date == DateToCheck.Date)
                            {
                                IsHoliday = true;
                                HolidayName = @"Memorial Day";
                            }
                        }
                    }
                }
            }

            return IsHoliday;
        }

        private bool IsIndependenceDay()
        {

            if (HolidayMonth == 7 && HolidayDay == 3 && DateToCheck.DayOfWeek == DayOfWeek.Friday)
            {
                IsHoliday = true;
                HolidayName = @"Independence Day";
                return IsHoliday;
            }

            if (HolidayMonth == 7 && HolidayDay == 5 && DateToCheck.DayOfWeek == DayOfWeek.Monday)
            {
                IsHoliday = true;
                HolidayName = @"Independence Day";
                return IsHoliday;
            }

            //Independence Day (July 4).
            if (HolidayDay == 4 && HolidayMonth == 7)
            {
                IsHoliday = true;
                HolidayName = @"Independence Day";
            }

            return IsHoliday;
        }

        private bool IsLaborDay()
        {
            //Labor Day (First Monday in September).
            if (HolidayMonth == 9)
            {
                if (DateToCheck.DayOfWeek == DayOfWeek.Monday && DateToCheck.Day < 8)
                {
                    IsHoliday = true;
                    HolidayName = @"Labor Day";
                }
            }

            return IsHoliday;
        }

        private bool IsColumbusDay()
        {
            //Columbus Day (Second Monday in October).
            if (HolidayMonth == 10)
            {
                if (DateToCheck.DayOfWeek == DayOfWeek.Monday && DateToCheck.Day > 7 && DateToCheck.Day < 15)
                {
                    IsHoliday = true;
                    HolidayName = @"Columbus Day";
                }
            }

            return IsHoliday;
        }

        private bool IsVeteransDay()
        {

            if (HolidayMonth == 11 && HolidayDay == 10 && DateToCheck.DayOfWeek == DayOfWeek.Friday)
            {
                IsHoliday = true;
                HolidayName = @"Veterans Day";
                return IsHoliday;
            }

            if (HolidayMonth == 11 && HolidayDay == 12 && DateToCheck.DayOfWeek == DayOfWeek.Monday)
            {
                IsHoliday = true;
                HolidayName = @"Veterans Day";
                return IsHoliday;
            }

            //Veterans Day (November 11).
            if (HolidayDay == 11 && HolidayMonth == 11)
            {
                IsHoliday = true;
                HolidayName = @"Veterans Day";
            }

            return IsHoliday;
        }

        private bool IsThanksgivingDay()
        {
            //Thanksgiving Day (Fourth Thursday in November).
            if (HolidayMonth == 11)
            {
                if (DateToCheck.DayOfWeek == DayOfWeek.Thursday && DateToCheck.Day > 21)
                {
                    var thanksgiving = (from day in Enumerable.Range(1, 30)
                                        where new DateTime(DateToCheck.Year, 11, day).DayOfWeek == DayOfWeek.Thursday
                                        select day).ElementAt(3);
                    DateTime thanksgivingDay = new DateTime(DateToCheck.Year, 11, thanksgiving);

                    if (thanksgivingDay == DateToCheck)
                    {
                        IsHoliday = true;
                    }

                }
            }

            return IsHoliday;
        }

        private bool IsChristmas()
        {
            if (HolidayMonth == 12 && HolidayDay == 24 && DateToCheck.DayOfWeek == DayOfWeek.Friday)
            {
                IsHoliday = true;
                HolidayName = @"Christmas";
                return IsHoliday;
            }

            if (HolidayMonth == 12 && HolidayDay == 26 && DateToCheck.DayOfWeek == DayOfWeek.Monday)
            {
                IsHoliday = true;
                HolidayName = @"Christmas";
                return IsHoliday;
            }

            if (HolidayDay == 25 && HolidayMonth == 12)
            {
                IsHoliday = true;
                HolidayName = @"Christmas";
            }

            return IsHoliday;
        }


        private void ParseDate(DateTime CheckHolidayDate)
        {
            DateToCheck = CheckHolidayDate;
            HolidayMonth = CheckHolidayDate.Month;
            HolidayDay = CheckHolidayDate.Day;
            HolidayYear = CheckHolidayDate.Year;
            HolidayDayOfWeek = CheckHolidayDate.DayOfWeek.ToString();
        }



    }


}
