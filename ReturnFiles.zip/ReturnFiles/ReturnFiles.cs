﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Security;
using System.Security.Permissions;
using System.Web;
using System.Globalization;
using Microsoft.Reporting.WebForms;
using System.Configuration;


namespace ReturnFiles
{
    /// <summary>
    /// Case Maintenance
    /// </summary>
    public class CaseMaintenance
    {
        public CaseMaintenance()
        {

        }

        private class CaseMaintenanceHeader
        {
            public string RecordType { get; set; }          //Char 2 - value is always HC
            public string StateUniqueData { get; set; }     //Char 15 - spaces
            public string AgencyCode { get; set; }          //Char 6 - ALMED
            public string MaintenanceType { get; set; }     //Char 16 - Case/Client
            public string FileCreateDate { get; set; }        //Char 8
            public string FileCreateTime { get; set; }      //Char 4
            public string Filler { get; set; }              //Char 169

            public CaseMaintenanceHeader()
            {
            }

        }

        public class CaseMaintenanceDetail
        {
            public string RefreshAction { get; set; }
            public string EBTAccountNumber { get; set; }
            public string CaseNumber { get; set; }
            public string ClientType { get; set; }
            public string CaseWorkerID { get; set; }
            public string DistrictOfficeCode { get; set; }
            public string ClientFirstName { get; set; }
            public string ClientMiddleName { get; set; }
            public string ClientLastName { get; set; }
            public string StreetAddress1 { get; set; }
            public string StreetAddress2 { get; set; }
            public string City { get; set; }
            public string State { get; set; }
            public string ZipCode { get; set; }
            public string BirthDate { get; set; }
            public string SocialSecurityNumber { get; set; }
            public string IssueCardFlag { get; set; }
            public string GeneratePINFlag { get; set; }
            public string DropShip { get; set; }
            public string Filler1 { get; set; }
            public string LanguageIndicator { get; set; }
            public string FileCreateDate { get; set; }
            public string FileCreateTime { get; set; }
            public string Filler2 { get; set; }

        }

        private class CaseMaintenanceTrailer
        {

            public string RecordType { get; set; }
            public string TotalDetailRecords { get; set; }
            public string NumberOfAdds { get; set; }
            public string NumberOfChanges { get; set; }
            public string Filler1 { get; set; }
            public string FileCreateDate { get; set; }
            public string FileCreateTime { get; set; }
            public string Filler2 { get; set; }


            public CaseMaintenanceTrailer(int _TotalDetailRecords, int _NumberOfAdds, int _NumberOfChanges, DateTime runTime)
            {
                this.RecordType = "TC";
                this.TotalDetailRecords = _TotalDetailRecords.ToString().Trim().PadLeft(9, '0');
                this.NumberOfAdds = _NumberOfAdds.ToString().Trim().PadLeft(9, '0');
                this.NumberOfChanges = _NumberOfChanges.ToString().PadLeft(9, '0');
                this.Filler1 = new string('0', 54);
                this.FileCreateDate = runTime.ToString("yyyyMMdd");
                this.FileCreateTime = runTime.ToString("HHmm");
                this.Filler2 = new string(' ', 125);
            }

            public string WriteFileTrailer()
            {

                StringBuilder sb = new StringBuilder();

                sb.Append(RecordType);
                sb.Append(TotalDetailRecords);
                sb.Append(NumberOfAdds);
                sb.Append(NumberOfChanges);
                sb.Append(Filler1);
                sb.Append(FileCreateDate);
                sb.Append(FileCreateTime);
                sb.Append(Filler2);

                return sb.ToString();
            }
        }
    }

    /// <summary>
    /// Case Benefit
    /// </summary>
    public class CaseBenefit
    {


        private class CaseBenefitHeader
        {
            public string RecordType { get; set; }
            public string StateUniqueData { get; set; }
            public string AgencyCode { get; set; }
            public string MaintenanceType { get; set; }
            public string FileCreateDate { get; set; }
            public string FileCreateTime { get; set; }
            public string Filler { get; set; }

            public CaseBenefitHeader()
            {
            }

            public CaseBenefitHeader(DateTime runTime)
            {

                this.RecordType = "HB";
                this.StateUniqueData = "ALMEDMB";
                this.AgencyCode = "ALMED".PadRight(6);
                this.MaintenanceType = "MED DAILY".PadRight(16);

                //this.FileCreateDate = fdt.FormatDate(DateTime.Now);
                this.FileCreateDate = runTime.ToString("yyyyMMdd");
                this.FileCreateTime = runTime.ToString("HHmm");

                //this.Filler = new string(' ', 29);

                this.Filler = new string(' ', 28);

            }
        }

        public class CaseBenefitDetail
        {
            public string RefreshAction { get; set; }
            public string EBTAccountNumber { get; set; }
            public string CaseNumber { get; set; }
            public string BenefitType { get; set; }
            public string AuthorizationNumber { get; set; }
            public string AuthorizationAmount { get; set; }
            public string BenefitAvailableDate { get; set; }
            public string BenefitAvailableTime { get; set; }
            public string DistrictOfficeCode { get; set; }
            public string BenefitStatus { get; set; }
            public string FileCreateDate { get; set; }
            public string FileCreateTime { get; set; }
            public string Filler { get; set; }
        }

        public class CaseBenefitTrailer
        {
            public string RecordType { get; set; }
            public string TotalDetailRecords { get; set; }
            public string NumberOfAdds { get; set; }
            public string NumberOfChanges { get; set; }
            public string NumberOfDeletes { get; set; }
            public string AmountOfAdds { get; set; }
            public string FileCreateDate { get; set; }
            public string FileCreateTime { get; set; }
            public string Filler { get; set; }
        }


    }

    /// <summary>
    /// Vendor Maintenanace
    /// </summary>
    public class VendorMaintenance
    {
        private class VendorMaintenanceHeader
        {
            public string RecordType { get; set; }
            public string AgencyUnique { get; set; }
            public string AgencyCode { get; set; }
            public string MaintenanceType { get; set; }
            public string FileCreateDate { get; set; }
            public string FileCreateTime { get; set; }
            public string Filler { get; set; }
        }

        public class VendorMaintenanceDetail
        {
            public string RefreshAction { get; set; }
            public string TransporterNumber { get; set; }
            public string AccountType { get; set; }
            public string ABARoutingNumber { get; set; }
            public string BankAccountNumber { get; set; }
            public string TransporterName { get; set; }
            public string TransportStreetAddress1 { get; set; }
            public string TransporterStreetAddress2 { get; set; }
            public string TransporterCity { get; set; }
            public string TransporterState { get; set; }
            public string TransporterZIP { get; set; }
            public string TransporterType { get; set; }
        }

        private class VendorMaintenanceTrailer
        {
            public string RecordType { get; set; }
            public string TotalDetailRecords { get; set; }
            public string NumberOfAdds { get; set; }
            public string NumberOfChanges { get; set; }
            public string Filler { get; set; }
        }
    }


    /// <summary>
    /// Vendor Benefit
    /// </summary>
    public class VendorBenefit
    {

        private class VendorBenefitHeader
        {
            public string RecordType { get; set; }
            public string AgencyUnique { get; set; }
            public string AgencyCode { get; set; }
            public string MaintenanceType { get; set; }
            public string FileCreateDate { get; set; }
            public string FileCreateTime { get; set; }
            public string Filler { get; set; }
        }

        public class VendorBenefitDetail
        {

            public string RefreshAction { get; set; }
            public string EBTAccountNumber { get; set; }
            public string CaseNumber { get; set; }
            public string BenefitType { get; set; }
            public string AuthorizationNumber { get; set; }
            public string AuthorizationAmount { get; set; }
            public string BenefitAvailableDate { get; set; }
            public string BenefitAvailableTime { get; set; }
            public string DistrictOfficeCode { get; set; }
            public string BenefitStatus { get; set; }
            public string TransporterNumber { get; set; }
            public string TransporterClientID { get; set; }
            public string FileCreateDate { get; set; }
            public string FileCreateTime { get; set; }
            public string Filler { get; set; }
        }

        private class VendorBenefitTrailer
        {
            public string RecordType { get; set; }
            public string TotalDetailRecords { get; set; }
            public string NumberOfAdds { get; set; }
            public string NumberOfCancels { get; set; }
            public string AmountOfAdds { get; set; }
            public string Filler { get; set; }
        }

    }
    /// <summary>
    /// AccountNumberMaintenance
    /// </summary>
    public class AccountNumberMaintenance
    {
        public AccountNumberMaintenance()
        {

        }

        public class AccountNumberMaintenanceHeader
        {
            public string RecordType { get; set; }          //Char 2 - value is always HE
            public string Description { get; set; }         //Char 20 - Constant = “EBT ACCOUNTS EXTRACT”
            public string AgencyCode { get; set; }          //Char 6 - ALMED
            public string FileCreateDate { get; set; }      //Char 8
            public string FileCreateTime { get; set; }      //Int 4
            public string ControlNumber { get; set; }       //Int 6
            public string Filler { get; set; }              //Char 34 - Spaces

            public AccountNumberMaintenanceHeader()
            {
                AccountNumberMaintenanceDetail anm = new AccountNumberMaintenanceDetail();
            }
        }

        public class AccountNumberMaintenanceDetail
        {
            public string AccountNumber { get; set; }          //Char 12 - EPPIC generated EBT account number available to the State to assign to new accounts
            public string Filler { get; set; }                 //Char - 68 - Spaces 

            public AccountNumberMaintenanceDetail()
            {
            }


        }

        public class AccountNumberMaintenanceTrailer
        {
            public string RecordType { get; set; }             //char - 1-2
            public string DetailRecordCount { get; set; }        //Char - 9 - Count of detail records in file
            public string Filler { get; set; }                   //Char - 69 - Spaces   
        }

    }

    /// <summary>
    /// HistoryExtract
    /// </summary>
    public class HistoryExtract
    {
        public HistoryExtract()
        {
        }

        public bool TestFile(DateTime date)
        {
            string Filepath = System.Configuration.ConfigurationManager.AppSettings["HEfilePath"];

            DirectoryInfo info = new DirectoryInfo(Filepath);
            FileInfo[] files = info.GetFiles().Where(p => p.Extension != ".pdf").OrderByDescending(p => p.CreationTime).ToArray();
            foreach (FileInfo file in files)
            {
                if (file.CreationTime.Date == date.Date)
                {
                    return true;
                }

            }

            return false;
        }

        /// <summary>
        /// HistoryExtractReport
        /// </summary>
        /// <param name="date">Based on calendar</param>
        /// <returns>list based on report</returns>
        public List<HistoryExtractDetail> HistoryExtractReport(DateTime date)
        {
            List<HistoryExtractDetail> _list = new List<HistoryExtractDetail>();

            ////Filepath 
            //string Filepath = @"\\prodsqletl16\MedicaidNET\TEST\History Extract";

            string Filepath = System.Configuration.ConfigurationManager.AppSettings["HEfilePath"];

            DirectoryInfo info = new DirectoryInfo(Filepath);
            FileInfo[] files = info.GetFiles().Where(p => p.Extension != ".pdf").OrderByDescending(p => p.CreationTime).ToArray();
            bool fileExist = true;

            foreach (FileInfo file in files)
            {
                if (file.CreationTime.Date == date.Date)
                {
                    if (fileExist)
                    {
                        fileExist = false;
                        string[] lines = File.ReadAllLines(file.FullName);
                        foreach (string line in lines)
                        {
                            //TODO: need to work on list based on Incoming  file.

                            if (line.Substring(0, 2) == "EH")   //Don't care about the header - at least not now
                            {
                                continue;
                            }

                            if (line.Substring(0, 2) == "ET")   //Don't care about the trailer - at least not now
                            {
                                break;
                            }

                            //TODO: list based on report
                            string _EBTAccountNumber = line.Substring(0, 12);
                            string _CaseNumber = line.Substring(12, 12);
                            string _AuthorizationNumber = line.Substring(24, 10);
                            string _UpdatedType = line.Substring(34, 2);
                            string _BenefitType = line.Substring(36, 6).Trim();
                            string _ReportCategory = line.Substring(42, 2);
                            string _primaryAccountNUmber = line.Substring(44, 19);
                            string _AvailableBalance = line.Substring(63, 9).TrimStart('0');
                            if (_AvailableBalance == "")
                            {
                                _AvailableBalance = "0.00";
                            }
                            if (_AvailableBalance != null)
                            {
                                _AvailableBalance = string.Format("{0:C}", Convert.ToDecimal(_AvailableBalance) / 100);
                            }
                            string _TransactionAmount = line.Length > 72 ? line.Substring(72, 9).TrimStart('0') : "0.00";
                            if (_TransactionAmount == "")
                            {
                                _TransactionAmount = "0.00";
                            }
                            if (_TransactionAmount != null)
                            {
                                _TransactionAmount = string.Format("{0:C}", Convert.ToDecimal(_TransactionAmount) / 100);
                            }

                            string _TransactionDate = line.Substring(81, 8);
                            if (_TransactionDate != null)
                            {

                                DateTime td = DateTime.ParseExact(_TransactionDate, "yyyyMMdd", CultureInfo.InvariantCulture);

                                _TransactionDate = td.ToString("MM/dd/yyyy");

                            }
                            string _Transactiontime = line.Substring(89, 4);
                            if (_Transactiontime != null)
                            {
                                DateTime tt = DateTime.ParseExact(_Transactiontime, "HHmm", CultureInfo.InvariantCulture);

                                _Transactiontime = tt.ToString("h:mm tt");
                            }
                            string _DistrictCode = line.Substring(93, 3).Trim();
                            string _TerminalID = line.Length > 96 ? line.Substring(96, 10).Trim() : " ";
                            string _FNSNumber = line.Length > 106 ? line.Substring(106, 7).Trim() : " ";
                            string _StoreName = line.Length > 114 ? line.Substring(113, 20).Trim() : " ";
                            string _StoreAbbrevation = line.Length > 133 ? line.Substring(133, 2) : " ";

                            _list.Add(new HistoryExtractDetail()
                            {
                                EBTAccountNumber = _EBTAccountNumber,
                                CaseNumber = _CaseNumber,
                                AuthorizationNumber = _AuthorizationNumber,
                                UpdateType = _UpdatedType,
                                BenefitType = _BenefitType,
                                ReportCategory = _ReportCategory,
                                PrimaryAccountNumber = _primaryAccountNUmber,
                                AvailableBalance = _AvailableBalance,
                                TransactionAmount = _TransactionAmount,
                                TransactionDate = _TransactionDate,
                                TransactionTime = _Transactiontime,
                                DistrictOfficeCode = _DistrictCode,
                                TerminalID = _TerminalID,
                                FNSNumber = _FNSNumber,
                                StoreName = _StoreName,
                                StoreStateAbbreviation = _StoreAbbrevation

                            });

                        }
                    }
                }
            }
            return _list;

        }

        private class HistoryExtractHeader
        {
            public string RecordType { get; set; }          //char 2 - value is always HE
            public string AgencyCode { get; set; }          //char 6 - "ALMED(= Medicaid)"
            public string FileType { get; set; }            //Char 16- Constant value of "HISTORYEXTRACT"
            public string FileCreateDate { get; set; }      //Char 8 - Format-YYYYMMDD
            public string FileCreateTime { get; set; }      //Char 4 - Format - HHMM
            public string ControlNumber { get; set; }       //Char 6 - Incremented by one each time sent. Control number sequencing will be checked separately for each unique file. See failure scenarios below.
            public string Filler { get; set; }              //Char-108 - Spaces
        }


        public class HistoryExtractDetail
        {
            public string EBTAccountNumber { get; set; }            //Char - 12 - EBT account number assigned by the State from the list provided by EPPIC
            public string CaseNumber { get; set; }                  //Char - 12 - Medicaid Number
            public string AuthorizationNumber { get; set; }         //Char - 10
            public string UpdateType { get; set; }                  //Cahr - 2- Valid Values are: "DR" (Debit to an authorization - e.g. withdrawal )"CR" (Credit to authorization -e.g. addition) 
            public string BenefitType { get; set; }                 //Char - 6- See Enumeration Table in Appendix A
            public string ReportCategory { get; set; }              //Char - 2- Valid values are:“CL” – Client Initiated Transactions (including reversals, voids, and returns) 
            public string PrimaryAccountNumber { get; set; }        //Char - 19
            public string AvailableBalance { get; set; }            //Char - 9
            public string TransactionAmount { get; set; }           //Char - 9
            public string TransactionDate { get; set; }             //Char - 8
            public string TransactionTime { get; set; }             //Char - 4
            public string DistrictOfficeCode { get; set; }          //Char - 3 - See Appaendex A for a list
            public string TerminalID { get; set; }                  //Char - 10 - POS terminal ID
            public string FNSNumber { get; set; }                   //Char - 7 - FNS Retailer Number
            public string StoreName { get; set; }                   //Char - 20
            public string StoreStateAbbreviation { get; set; }      //Char - 2 
            public string Filler { get; set; }                      //Char - 15

        }

        private class HistoryExtractTrailer
        {
            public string RecordType { get; set; }       //Char - 2 - "ET"
            public string AgenceyCode { get; set; }      //Char - 6 - Valid values are: "ALMED" = Medicaid
            public string FileCreateDate { get; set; }   //Char - 8 - YYYYMMDD
            public string FileCreatedTime { get; set; }  //Char - 4 - HHMM
            public string NumberOfRecords { get; set; }  //Char - 8 - Total number of detail records on the file
            public string Filler { get; set; }           //Char - 122 - Spaces
        }

        public class HistoryExtractProgramSummary
        {
            public string RecordType { get; set; }                      //Char - 2 - Constant of "ES"
            public string BenfitType { get; set; }                      //Char - 6 - Should always be "NET" for Medicaid
            public string BeginningBalance { get; set; }                //Char - 13 - Dollar amount for this program at the beginning of the process cycle
            public string EndingBalance { get; set; }                   //Char - 13 - Doallar amount for this program at the end of processing cycle
            public string AccumulatedAuthorizationAmount { get; set; }  //Char - 13 - Doallar amount of all authorizations for this program cycle 
            public string AccumulatedCancelsAmount { get; set; }        //Char - 13- Dollar amount of all cancels for this program of cycle
            public string AccumulatedTransactionAmount { get; set; }    //Char - 13 - Dollar amount of all client transaction
            public string FileCreateDate { get; set; }                  //Char - 08 - format YYYYMMDD
            public string FileCreateTime { get; set; }                  //Char - 04 -  HHMM
            public string Filler { get; set; }                          //Char - 65 - Spaces


        }
    }


    /// <summary>
    /// BenefitExpungement
    /// </summary>
    public class BenefitExpungement
    {

        public bool TestFile(DateTime date)
        {
            string Filepath = System.Configuration.ConfigurationManager.AppSettings["BEfilePath"];

            DirectoryInfo info = new DirectoryInfo(Filepath);
            FileInfo[] files = info.GetFiles().Where(p => p.Extension != ".pdf").OrderByDescending(p => p.CreationTime).ToArray();
            foreach (FileInfo file in files)
            {
                if (file.CreationTime.Date == date.Date)
                {
                    return true;
                }

            }

            return false;
        }

        public List<BenefitExpungementDetail> BenefitExpungementReport(DateTime date)
        {
            List<BenefitExpungementDetail> _list = new List<BenefitExpungementDetail>();


            //string Filepath = @"\\prodsqletl16\MedicaidNet\TEST\Expungement";

            string Filepath = System.Configuration.ConfigurationManager.AppSettings["BEfilePath"];

            DirectoryInfo info = new DirectoryInfo(Filepath);
            bool fileExist = true;
            //Order by Created time
            FileInfo[] files = info.GetFiles().Where(p => p.Extension != ".pdf").OrderByDescending(p => p.CreationTime).ToArray();

            foreach (FileInfo file in files)
            {
                if (file.CreationTime.Date == date.Date)
                {
                    if (fileExist)
                    {
                        fileExist = false;
                        string[] lines = File.ReadAllLines(file.FullName);
                        foreach (string line in lines)
                        {
                            // need to work on list based on Incoming  file.

                            if (line.Substring(0, 2) == "AH")   //Don't care about the header - at least not now
                            {

                                continue;

                            }

                            if (line.Substring(0, 2) == "AT")   //Don't care about the trailer - at least not now
                            {
                                break;
                            }

                            string _EBTAccountNUmber = line.Substring(0, 12);
                            string _CaseNumber = line.Substring(12, 12);
                            string _AuthorizationNumber = line.Substring(24, 10);
                            string _BenefitType = line.Substring(34, 6);
                            string _AgingIndicator = line.Substring(40, 1);
                            string _AvailableBalance = line.Length > 40 ? line.Substring(41, 9).TrimStart('0') : "0.00";
                            if (_AvailableBalance == "")
                            {
                                _AvailableBalance = "0.00";
                            }
                            if (_AvailableBalance != null)
                            {
                                _AvailableBalance = string.Format("{0:C}", Convert.ToDecimal(_AvailableBalance) / 100);
                            }
                            string _OriginalAuthAmount = line.Length > 50 ? line.Substring(50, 9).TrimStart('0') : "0.00";
                            if (_OriginalAuthAmount == "")
                            {
                                _OriginalAuthAmount = "0.00";
                            }
                            if (_OriginalAuthAmount != null)
                            {
                                _OriginalAuthAmount = string.Format("{0:C}", Convert.ToDecimal(_OriginalAuthAmount) / 100);
                            }
                            // TODO :list
                            _list.Add(new BenefitExpungementDetail()
                            {

                                EBTAccountNumber = _EBTAccountNUmber,
                                CaseNumber = _CaseNumber,
                                AuthorizationNumber = _AuthorizationNumber,
                                BenefitType = _BenefitType,
                                AgingIndicator = _AgingIndicator,
                                AvailableBalance = _AvailableBalance,
                                OriginalAuthAmount = _OriginalAuthAmount,

                            });

                        }
                    }
                }
            }

            return _list;
        }
        private class BenefitExpungementHeader
        {
            public string RecordType { get; set; }             //Char - 2 - Constant of "AH"
            public string AgencyCode { get; set; }             //Char - 06 - "ALMED" = Medicaid
            public string FileType { get; set; }               //Char - 16 - Constant value of "AGINGEXTRACT"
            public string FileCreateDate { get; set; }         //Char - 08 - YYYYMMDD format
            public string FileCreateTime { get; set; }         //Char - 04 - HHMM format
            public string ControlNumber { get; set; }          //Char - 06 -Incremented by 1 each time sent.
            public string Filler { get; set; }                 //Char - 38 - Spaces
        }

        public class BenefitExpungementDetail
        {
            public string EBTAccountNumber { get; set; }            //Char - 12 - EBT account number assigned by the State from the list provided by Conduent
            public string CaseNumber { get; set; }                  //Char - 12 - Medicaid Number
            public string AuthorizationNumber { get; set; }         //Char - 10
            public string BenefitType { get; set; }                  //Char - 06
            public string AgingIndicator { get; set; }              //Char - 01 - "3" - Expunged Benfits (Medicaid benfits 90 days or older - regardless of last used time stamp)
            public string AvailableBalance { get; set; }            //Char - 09 - Amount of funds remaing on the benfit
            public string OriginalAuthAmount { get; set; }          //Char - 09 - Original Authorized anount
            public string FileCreateDate { get; set; }              //Char - 08 - YYYYMMDD format
            public string FileCreateTime { get; set; }              //Char - 04 - HHMM format 
            public string Filler { get; set; }                      //Char - 09 - Sapces
        }

        private class BenefitExpungementTrailer
        {
            public string RecordType { get; set; }           //Char - 02 - Constant of "AT"
            public string AgencyCode { get; set; }           //Char - 06 - "ALMED" - Medicaid
            public string FileCreateDate { get; set; }       //Char - 08 - YYYYMMDD format
            public string FileCreateTime { get; set; }       //Char - 04 - HHMM Format
            public string NumberOfRecords { get; set; }      //Char - 08 - Total number of Detail records in file
            public string Filler { get; set; }               //Char - 52 - Spaces

        }
    }


    /// <summary>
    /// UndeliverableCardStatus
    /// </summary>
    public class UndeliverableCardStatus
    {


        public UndeliverableCardStatus()
        {
        }


        public bool TestFile(DateTime date)
        {
            string Filepath = System.Configuration.ConfigurationManager.AppSettings["UNfilePath"];

            DirectoryInfo info = new DirectoryInfo(Filepath);
            FileInfo[] files = info.GetFiles().Where(p => p.Extension != ".pdf").OrderByDescending(p => p.CreationTime).ToArray();
            foreach (FileInfo file in files)
            {
                if (file.CreationTime.Date == date.Date)
                {
                    return true;
                }

            }

            return false;
        }

        public List<UndeliverableCardStatusDetail> UndeliverableCardStatusReport(DateTime date)
        {

            List<UndeliverableCardStatusDetail> _list = new List<UndeliverableCardStatusDetail>();

            string Filepath = System.Configuration.ConfigurationManager.AppSettings["UNfilePath"];

            DirectoryInfo info = new DirectoryInfo(Filepath);
            FileInfo[] files = info.GetFiles().Where(p => p.Extension != ".pdf").OrderByDescending(p => p.CreationTime).ToArray();
            bool fileExist = true;
            foreach (FileInfo file in files)
            {
                if (file.CreationTime.Date == date.Date)
                {
                    if (fileExist)
                    {
                        fileExist = false;
                        string[] lines = File.ReadAllLines(file.FullName);
                        foreach (string line in lines)
                        {
                            if (line.Substring(0, 2) == "UH")   //Don't care about the header - at least not now
                            {
                                if (line.Substring(2, 5) == "ALMED")
                                {
                                    continue;
                                }
                                else
                                {
                                    break;
                                }
                            }

                            if (line.Substring(0, 2) == "UT")   //Don't care about the trailer - at least not now
                            {

                                break;
                            }

                            string _CaseNumber = line.Substring(0, 14).Trim();
                            string _Pan = line.Substring(14, 19);
                            string _LocalOffice = line.Substring(33, 3).Trim();
                            string _StatusDate = line.Substring(36, 8);

                            if (_StatusDate != null)
                            {
                                DateTime sd = DateTime.ParseExact(_StatusDate, "yyyyMMdd", CultureInfo.InvariantCulture);
                                _StatusDate = sd.ToString("MM/dd/yyyy");
                            }

                            _list.Add(new UndeliverableCardStatusDetail()
                            {
                                CaseNumber = _CaseNumber,
                                PrimaryAccountNumber = _Pan,
                                DistrictOfficeCode = _LocalOffice,
                                StatusDate = _StatusDate,
                            });

                        }
                    }
                }
            }

            return _list;
        }

        private class UndeliverableCardStatusHeader
        {
            public string RecordType { get; set; }             //Char - 2 - Constant of "UH"
            public string AgencyCode { get; set; }             //Char - 06 
            public string FileType { get; set; }               //Char - 16 - Constant value of "UNDELIVERED"
            public string FileCreateDate { get; set; }         //Char - 08 - YYYYMMDD format
            public string FileCreateTime { get; set; }         //Char - 04 - HHMM format
            public string ControlNumber { get; set; }          //Char - 06 -Incremented by 1 each time sent.
            public string Filler { get; set; }                 //Char - 38 - Spaces
        }

        public class UndeliverableCardStatusDetail
        {
            public string CaseNumber { get; set; }                //Char - 14
            public string PrimaryAccountNumber { get; set; }      //Char - 19 
            public string DistrictOfficeCode { get; set; }        //Char - 03 
            public string StatusDate { get; set; }                //Full date and time
            public string AdminUserID { get; set; }               //Char - 24 
            public string Filler { get; set; }                    //Char - 08 - spaces

        }

        public class UndeliverableCardStatusTrailer
        {
            public string RecordType { get; set; }             //Char - 02 - Constant of "UT"
            public string NumberOfRecords { get; set; }        //Char - 09 - Total number of Detail Records in file
            public string Filler { get; set; }                 //Char - 69 - spaces 
        }

    }

    /// <summary>
    /// AdjustmentNotification
    /// </summary>
    public class AdjustmentNotification
    {

        public bool TestFile(DateTime date)
        {
            string Filepath = System.Configuration.ConfigurationManager.AppSettings["ANfilePath"];

            DirectoryInfo info = new DirectoryInfo(Filepath);
            FileInfo[] files = info.GetFiles().Where(p => p.Extension != ".pdf").OrderByDescending(p => p.CreationTime).ToArray();
            foreach (FileInfo file in files)
            {
                if (file.CreationTime.Date == date.Date)
                {
                    return true;
                }

            }

            return false;
        }

        public List<AdjustmentNotificationDetail> AdjustmentNotificationReport(DateTime date)
        {
            List<AdjustmentNotificationDetail> _list = new List<AdjustmentNotificationDetail>();
 

            string Filepath = System.Configuration.ConfigurationManager.AppSettings["ANfilePath"];

            DirectoryInfo info = new DirectoryInfo(Filepath);
            FileInfo[] files = info.GetFiles().Where(p => p.Extension != ".pdf").OrderByDescending(p => p.CreationTime).ToArray();

            bool fileExist = true;

            foreach (FileInfo file in files)
            {
                if (file.CreationTime.Date == date.Date)
                {
                    if (fileExist)
                    {
                        fileExist = false;
                        //open file
                        string[] lines = File.ReadAllLines(file.FullName);
                        foreach (string line in lines)
                        {
                            // need to work on list based on Incoming  file.

                            if (line.Substring(0, 2) == "NH")   //Don't care about the header - at least not now
                            {

                                continue;
                            }

                            if (line.Substring(0, 2) == "NT")   //Don't care about the trailer - at least not now
                            {
                                break;
                            }

                            //TODO: list 

                            string _CaseNumber = line.Substring(0, 13).Trim();
                            string _FirstName = line.Substring(14, 15).Trim();
                            string _lastName = line.Substring(29, 20).Trim();
                            string _PAN = line.Substring(49, 19).TrimStart('0');
                            string _OrginalPAN = line.Substring(68, 19).TrimStart('0');
                            string _OrginalTransactionType = line.Length > 87 ? line.Substring(87, 3).Trim() : "";
                            string _AdjustmentTransactionType = line.Length > 90 ? line.Substring(90, 3).Trim() : "";
                            string _BenefitClass = line.Substring(93, 2);
                            string _OrginalTransactionDate = line.Length > 95 ? line.Substring(95, 8) : "";
                            if (_OrginalTransactionDate != null)
                            {
                                DateTime otd = DateTime.ParseExact(_OrginalTransactionDate, "yyyyMMdd", CultureInfo.InvariantCulture);
                                _OrginalTransactionDate = otd.ToString("MM/dd/yyyy");
                            }
                            string _OriginalTransactionTime = line.Length > 103 ? line.Substring(103, 4) : "";
                            if (_OriginalTransactionTime != null)
                            {
                                DateTime ott = DateTime.ParseExact(_OriginalTransactionTime, "HHmm", CultureInfo.InvariantCulture);
                                _OriginalTransactionTime = ott.ToString("h:mm tt");
                            }
                            string _AdjustmentAmount = line.Length > 107 ? line.Substring(107, 9).TrimStart('0') : "0.00";
                            if (_AdjustmentAmount != null)
                            {
                                _AdjustmentAmount = string.Format("{0:C}", Convert.ToDecimal(_AdjustmentAmount) / 100);
                            }
                            string _HoldAmount = line.Length > 116 ? line.Substring(116, 9).TrimStart('0') : "0.00";
                            if (_HoldAmount == "")
                            {
                                _HoldAmount = "0.00";
                            }
                            if (_HoldAmount != null)
                            {
                                _HoldAmount = string.Format("{0:C}", Convert.ToDecimal(_HoldAmount) / 100);
                            }
                            string _AdjustmentReason = line.Length > 125 ? line.Substring(125, 30).Trim() : "";
                            string _AdjustmentStatus = line.Length > 155 ? line.Substring(155, 1) : "";
                            string _NotificationIndicator = line.Length > 156 ? line.Substring(156, 1) : "";
                            string _MarchantName = line.Length > 157 ? line.Substring(157, 25).Trim() : "";
                            string _MarchantAddress = line.Length > 182 ? line.Substring(182, 23).Trim() : "";
                            string _MarchantCity = line.Length > 205 ? line.Substring(205, 13).Trim() : "";
                            string _MarchantState = line.Length > 218 ? line.Substring(218, 2) : " ";

                            _list.Add(new AdjustmentNotificationDetail()
                            {
                                CaseNumber = _CaseNumber,
                                FirstName = _FirstName,
                                LastName = _lastName,
                                PAN = _PAN,
                                OriginalPAN = _OrginalPAN,
                                OriginalTransactionType = _OrginalTransactionType,
                                AdjustmentTransactionType = _AdjustmentTransactionType,
                                BenfitClass = _BenefitClass,
                                OrginalTransactionDate = _OrginalTransactionDate,
                                OrginalTransactionTime = _OriginalTransactionTime,
                                AdjustmentAmount = _AdjustmentAmount,
                                HoldAmount = _HoldAmount,
                                AdjustmentReason = _AdjustmentReason,
                                AdjustmentStatus = _AdjustmentStatus,
                                NotificationIndicator = _NotificationIndicator,
                                MerchantName = _MarchantName,
                                MerchantAddress = _MarchantAddress,
                                MerchantCity = _MarchantCity,
                                MerchantState = _MarchantState

                            });

                        }
                    }
                }
            }
            return _list;


        }


        private class AdjustmentNotificationHeader
        {
            public string RecordType { get; set; }                  //Char - 02 - constant "NH"
            public string AgencyCode { get; set; }                  //Char - 06 
            public string FileType { get; set; }                    //Char - 16 - constant = adjustments
            public string FileCreateDate { get; set; }              //Char - 08 - YYYYMMDD format
            public string FileCreateTime { get; set; }              //Char - 04 - HHMM format
            public string ControlNumber { get; set; }               //Char - 06 - Increment 1 each time sent
            public string Filler { get; set; }                      //Char - 198 - spaces
        }

        public class AdjustmentNotificationDetail
        {
            public string CaseNumber { get; set; }                  //Char - 14 - Case# associated with benfit
            public string FirstName { get; set; }                   //Char - 15 - FirstName  of card holder
            public string LastName { get; set; }                    //Char - 15 - LastName of Card holder 
            public string PAN { get; set; }                         //Char - 19 - Recent PAN number
            public string OriginalPAN { get; set; }                 //Char - 19 - If not the same as current card
            public string OriginalTransactionType { get; set; }     //Char - 03 
            public string AdjustmentTransactionType { get; set; }   //Char - 03
            public string BenfitClass { get; set; }                 //Char - 02 - CA = Cash, SNAP = SNAP, NET = Medicaid 
            public string OrginalTransactionDate { get; set; }      //Char - 08 - YYYYMMDD format
            public string OrginalTransactionTime { get; set; }      //Char - 04 - HHMM format
            public string AdjustmentAmount { get; set; }            //Char - 09  - The total amount od the adjustment
            public string HoldAmount { get; set; }                  //Char - 09 - Tha amount of the current benfit placed on hold
            public string AdjustmentReason { get; set; }            //Char - 30 
            public string AdjustmentStatus { get; set; }            //Char - 01
            public string NotificationIndicator { get; set; }       //Char - 01
            public string MerchantName { get; set; }                //Char - 25
            public string MerchantAddress { get; set; }             //Char - 23
            public string MerchantCity { get; set; }                //Char - 13
            public string MerchantState { get; set; }               //Char - 02 
            public string Filler { get; set; }                      //Char - 20 - spaces

        }


        private class AdjustmentNotificationFileTrailer
        {
            public string RecordType { get; set; }              //Char - 02 - Constant of "NT"
            public string NumOfRecords { get; set; }            //Char - 09 
            public string Filler { get; set; }                  //Char - 229 - spaces
        }


    }
    /// <summary>
    /// Batch Process Summary
    /// </summary>
    public class BatchProcessSummary
    {

        private class BatchProcessingReturnHeader
        {
            public string OrginalHeader { get; set; }               //Char - 220 - From Incoming file
            public string ErrorCode { get; set; }                   //Char - 4 - "0000" no errors

        }
        private class BatchProcessingReturnDetail
        {
            public string OrginalDetailRecord { get; set; }         //Char - 220 - From Incoming File
            public string ErrorCode { get; set; }                  //Char - 4 - "0000" no errors
        }
        private class BatchProcessingReturnTrailer
        {
            public string OrginalTrailer { get; set; }              //Char - 220 - From Incoming file
            public string ErrorCode { get; set; }                   //Char - 4 - "0000" - no error
        }

    }

    /// <summary>
    /// Return file reports
    /// </summary>
    public class ReturnFileReports
    {

 

        public ReturnFileReports()
        {

        }

        /// <summary>
        /// Undeliverable CardReport
        /// </summary>
        /// <returns>local rdlc report</returns>
        public byte[] UndeliverableCardReport(DateTime Date)
        {

   

            UndeliverableCardStatus udcs = new UndeliverableCardStatus();


            ReportDataSource rds = new ReportDataSource("DataSet1", udcs.UndeliverableCardStatusReport(Date));

            Warning[] warnings;
            string[] streamIds;
            string mimeType = string.Empty;
            string encoding = string.Empty;
            string extension = string.Empty;

            string paraDate = Date.Date.ToShortDateString();
            ReportParameter[] param = new ReportParameter[2];
            param[0] = new ReportParameter("calenderDate", paraDate, true);
            param[1] = new ReportParameter("totalCount", rds.Value.ToString(), true);

            // Setup the report viewer object and get the array of bytes
            ReportViewer viewer = new ReportViewer();
            viewer.ProcessingMode = ProcessingMode.Local;
            viewer.LocalReport.ReportPath = "../ReturnFiles/Reports/UndeliverableCards.rdlc";
            viewer.LocalReport.DataSources.Add(rds);
            viewer.LocalReport.SetParameters(param);
            viewer.LocalReport.SetBasePermissionsForSandboxAppDomain(new PermissionSet(PermissionState.Unrestricted));
            byte[] bytes = viewer.LocalReport.Render("PDF", null, out mimeType, out encoding, out extension, out streamIds, out warnings);

            return bytes;

        }



        /// <summary>
        /// History Extract Report
        /// </summary>
        /// <returns> local rdlc report</returns>
        public byte[] HistoryExtractReport(DateTime date)
        {
            HistoryExtract he = new HistoryExtract();

            ReportDataSource rds = new ReportDataSource("DataSet1", he.HistoryExtractReport(date));


            Warning[] warnings;
            string[] streamIds;
            string mimeType = string.Empty;
            string encoding = string.Empty;
            string extension = string.Empty;

            string paraDate = date.Date.ToShortDateString();
            ReportParameter[] param = new ReportParameter[2];
            param[0] = new ReportParameter("calenderDate", paraDate, true);
            param[1] = new ReportParameter("totalCount", rds.Value.ToString(), true);


            // Setup the report viewer object and get the array of bytes
            ReportViewer viewer = new ReportViewer();
            viewer.ProcessingMode = ProcessingMode.Local;
            viewer.LocalReport.ReportPath = "../ReturnFiles/Reports/HistoryExtract.rdlc";
            viewer.LocalReport.DataSources.Add(rds);
            viewer.LocalReport.SetParameters(param);
            viewer.LocalReport.SetBasePermissionsForSandboxAppDomain(new PermissionSet(PermissionState.Unrestricted));
            byte[] bytes = viewer.LocalReport.Render("PDF", null, out mimeType, out encoding, out extension, out streamIds, out warnings);
            return bytes;
        }

        /// <summary>
        /// Benefit Expungement Report
        /// </summary>
        /// <returns>local rdlc report</returns>
        public byte[] BenefitExpungementReport(DateTime date)
        {
            BenefitExpungement be = new BenefitExpungement();

            ReportDataSource rds = new ReportDataSource("DataSet1", be.BenefitExpungementReport(date));

            Warning[] warnings;
            string[] streamIds;
            string mimeType = string.Empty;
            string encoding = string.Empty;
            string extension = string.Empty;



            string paraDate = date.Date.ToShortDateString();
            ReportParameter[] param = new ReportParameter[2];
            param[0] = new ReportParameter("calenderDate", paraDate, true);
            param[1] = new ReportParameter("totalCount", rds.Value.ToString(), true);


            // Setup the report viewer object and get the array of bytes
            ReportViewer viewer = new ReportViewer();
            viewer.ProcessingMode = ProcessingMode.Local;
            viewer.LocalReport.ReportPath = "../ReturnFiles/Reports/BenefitExpungement.rdlc";
            viewer.LocalReport.DataSources.Add(rds);
            viewer.LocalReport.SetParameters(param);
            viewer.LocalReport.SetBasePermissionsForSandboxAppDomain(new PermissionSet(PermissionState.Unrestricted));

            byte[] bytes = viewer.LocalReport.Render("pdf", null, out mimeType, out encoding, out extension, out streamIds, out warnings);
            return bytes;
        }

        /// <summary>
        /// AdjustmentNotificationReport
        /// </summary>
        /// <returns>local rdlc report</returns>
        public byte[] AdjustmentNotificationReport(DateTime date)
        {
            AdjustmentNotification an = new AdjustmentNotification();

            ReportDataSource rds = new ReportDataSource("DataSet1", an.AdjustmentNotificationReport(date));

            Warning[] warnings;
            string[] streamIds;
            string mimeType = string.Empty;
            string encoding = string.Empty;
            string extension = string.Empty;



            string paraDate = date.Date.ToShortDateString();
            ReportParameter[] param = new ReportParameter[2];
            param[0] = new ReportParameter("calenderDate", paraDate, true);
            param[1] = new ReportParameter("totalCount", rds.Value.ToString(), true);

            // Setup the report viewer object and get the array of bytes
            ReportViewer viewer = new ReportViewer();
            viewer.ProcessingMode = ProcessingMode.Local;
            viewer.LocalReport.ReportPath = "../ReturnFiles/Reports/AdjustmentNotification.rdlc";
            viewer.LocalReport.DataSources.Add(rds);
            viewer.LocalReport.SetParameters(param);
            viewer.LocalReport.SetBasePermissionsForSandboxAppDomain(new PermissionSet(PermissionState.Unrestricted));
            byte[] bytes = viewer.LocalReport.Render("PDF", null, out mimeType, out encoding, out extension, out streamIds, out warnings);
            return bytes;
        }


        public string FileNameDate(DateTime date)
        {
 
            string returnDate = "AL" + date.Year.ToString().Trim();

            string mth = date.Month.ToString().Trim();
            mth = mth.Length == 1 ? "0" + mth : mth;

            string day = date.Day.ToString().Trim();
            day = day.Length == 1 ? "0" + day : day;

            returnDate = returnDate + mth + day;

            return returnDate;
        }

    }

}
