﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StateHoliday
{
    public class StateHoliday
    {
        /// <summary>
        /// Denotes if the checked date is a state holiday
        /// </summary>
        private bool _isHoliday;
        public bool IsHoliday
        {
            get
            {
                return _isHoliday;
            }
            set
            {
                _isHoliday = value;
            }
        }

        /// <summary>
        /// The name of the holiday
        /// </summary>
        private string _holiday;
        public string Holiday
        {
            get
            {
                return _holiday;
            }
            set
            {
                _holiday = value;
            }
        }

        /// <summary>
        /// Date we're checking
        /// </summary>
        private DateTime date;

        /// <summary>
        /// Check the current date against state holidays
        /// </summary>
        public StateHoliday()
        {
            date = DateTime.Now;
            CheckForHoliday();
        }

        /// <summary>
        /// Check a passed in date against state holidays
        /// </summary>
        /// <param name="dateToCheck"></param>
        public StateHoliday(DateTime dateToCheck)
        {
            TimeSpan ts = new TimeSpan(00, 00, 0);
            dateToCheck = dateToCheck.Date + ts;

            date = dateToCheck;
            CheckForHoliday();
        }


        private void CheckForHoliday()
        {
            LeeMLK();
            WashingtonJefferson();
            ConfederateMemorialDay();
            JeffersonDavis();
            ColumbusDay();
            DayAfterThanksgiving();
        }

        private void LeeMLK()
        {
            if (date.Date == GetNthDayOfNthWeek(1, DayOfWeek.Monday, 3).Date)
            {
                if (DateTime.Now.Month == 1)
                {
                    Holiday = "Birthdays of Robert E. Lee/Martin Luther King Jr.";
                    IsHoliday = true;
                }
            }

        }

        private void WashingtonJefferson()
        {
            if (date.Date == GetNthDayOfNthWeek(2, DayOfWeek.Monday, 3).Date)
            {
                if (DateTime.Now.Month == 2)
                {
                    Holiday = "Birthdays of George Washington/Thomas Jefferson";
                    IsHoliday = true;
                }
            }
        }

        private void ConfederateMemorialDay()
        {
            //4th Monday in April
            if (date.Date == GetNthDayOfNthWeek(4, DayOfWeek.Monday, 4).Date)
            {
                if (DateTime.Now.Month == 4)
                {
                    Holiday = "Confederate Memorial Day";
                    IsHoliday = true;
                }
            }
        }

        private void JeffersonDavis()
        {
            if (date.Date == GetNthDayOfNthWeek(6, DayOfWeek.Monday, 1).Date)
            {
                if (DateTime.Now.Month == 6)
                {
                    Holiday = "Birthday of Jefferson Davis";
                    IsHoliday = true;
                }
            }
        }

        private void ColumbusDay()
        {
            if (date.Date == GetNthDayOfNthWeek(10, DayOfWeek.Monday, 2).Date)
            {
                if (DateTime.Now.Month == 10)
                {
                    Holiday = "Columbus Day/Fraternal Day/American Indian Heritage Day";
                    IsHoliday = true;
                }
            }
        }

        //TFS 4562
        private void DayAfterThanksgiving()
        {
            int HolidayMonth = DateTime.Now.Month;
            TimeSpan ts = new TimeSpan(00, 00, 0);
            DateTime DateToCheck = DateTime.Now.AddDays(-1);
            DateToCheck = DateToCheck.Date + ts;


            //Thanksgiving Day (Fourth Thursday in November).
            if (HolidayMonth == 11)
            {
                if (DateToCheck.DayOfWeek == DayOfWeek.Thursday && DateToCheck.Day > 21)
                {
                    var thanksgiving = (from day in Enumerable.Range(1, 30)
                                        where new DateTime(DateToCheck.Year, 11, day).DayOfWeek == DayOfWeek.Thursday
                                        select day).ElementAt(3);
                    DateTime thanksgivingDay = new DateTime(DateToCheck.Year, 11, thanksgiving);

                    if (thanksgivingDay == DateToCheck)
                    {
                        IsHoliday = true;
                    }

                }
            }




            //if (DateTime.Now.Month == 11)
            //{
            //    if (date.Date == GetNthDayOfNthWeek(11, DayOfWeek.Friday, 4).Date)
            //    {
            //        Holiday = "Day After Thanksgiving";
            //        IsHoliday = true;
            //    }
            //}
        }

        /// <summary>
        /// Gets the nth day of week in a particular month
        /// </summary>
        /// <param name="month">The month we're looking in</param>
        /// <param name="day">The day of the week (Sun,Mon,Tues..)</param>
        /// <param name="week">The week #</param>
        /// <returns></returns>
        private DateTime GetNthDayOfNthWeek(int month, DayOfWeek day, int week)
        {
            DateTime firstOfMonth = new DateTime(date.Year, month, 1);
            DateTime firstDayOfMonth; //first (x) of the month
            DateTime returnDate; //date to return

            if (day < firstOfMonth.DayOfWeek)
            {
                firstDayOfMonth = firstOfMonth.AddDays((day + 7) - firstOfMonth.DayOfWeek);
            }
            else
            {
                firstDayOfMonth = firstOfMonth.AddDays(day - firstOfMonth.DayOfWeek);
            }


            //get which week
            returnDate = firstDayOfMonth.AddDays((week - 1) * 7);

            //if day is past end of month then adjust backwards a week
            if (returnDate.Month > firstOfMonth.Month || returnDate.Year > firstOfMonth.Year)
            {
                returnDate = returnDate.AddDays(-7);
            }

            return returnDate;
        }
    }
}
