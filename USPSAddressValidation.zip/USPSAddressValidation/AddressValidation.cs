﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Xml.Linq;
using System.IO;

namespace USPSAddressValidation
{
    public class AddressValidation
    {
       //public string BaseURL = "https://stg-secure.shippingapis.com/ShippingAPI.dll";



       public string BaseURL = "https://secure.shippingapis.com/ShippingAPI.dll";

        public string USPS_UserID = "974ALABA5298";

        public string ErrorMessage { get; set; }


        public string USPSAddress { get; set; }
        public string USPSCity { get; set; }
        public string USPSState { get; set; }
        public string USPSZip5 { get; set; }
        public string USPSZip4 { get; set; }

        public AddressValidation()
        {
        }

        public bool ValidateAddress(string Address, string Address2, string City, string State, string Zip5, string Zip4)
        {

            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            Address = Address == null ? "" : Address;
            Address2 = Address2 == null ? "" : Address2;
            City = City == null ? "" : City;
            State = State == null ? "" : State;
            Zip5 = Zip5 == null ? "" : Zip5;
            Zip4 = Zip4 == null ? "" : Zip4;


            //try
            //{
            bool isValid = true;

            string strResponse = "";
            string strUSPS = "";
            ErrorMessage = "";

            strUSPS = BaseURL + @"?API=Verify&XML=<AddressValidateRequest USERID='" + USPS_UserID + @"'>";
            strUSPS += @"<Address ID='0'>";
            strUSPS += "<Address1>" + Address2 + "</Address1>";
            strUSPS += "<Address2>" + Address + "</Address2>";
            strUSPS += "<City>" + City + "</City>";
            strUSPS += "<State>" + State + "</State>";
            strUSPS += "<Zip5>" + Zip5 + "</Zip5>";
            strUSPS += "<Zip4>" + Zip4 + "</Zip4>";
            strUSPS += "</Address></AddressValidateRequest>";

            strUSPS = strUSPS.Replace("#", "");
            strUSPS = strUSPS.Replace("%", "");

            try
            {
                strResponse = GetDataFromSite(strUSPS);
            }
            catch
            {
                System.Threading.Thread.Sleep(500);
                strResponse = GetDataFromSite(strUSPS);
            }






            //try again with address swapped
            if (strResponse.Contains("Error"))
            {
                strUSPS = BaseURL + @"?API=Verify&XML=<AddressValidateRequest USERID='" + USPS_UserID + @"'>";
                strUSPS += @"<Address ID='0'>";
                strUSPS += "<Address1>" + Address + "</Address1>";
                strUSPS += "<Address2>" + Address2 + "</Address2>";
                strUSPS += "<City>" + City + "</City>";
                strUSPS += "<State>" + State + "</State>";
                strUSPS += "<Zip5>" + Zip5 + "</Zip5>";
                strUSPS += "<Zip4>" + Zip4 + "</Zip4>";
                strUSPS += "</Address></AddressValidateRequest>";

                strUSPS = strUSPS.Replace("#", "");
                strUSPS = strUSPS.Replace("%", "");

                try
                {
                    strResponse = GetDataFromSite(strUSPS);
                }
                catch
                {
                    System.Threading.Thread.Sleep(500);
                    strResponse = GetDataFromSite(strUSPS);
                }

            }

            XDocument docx;
            using (StringReader s = new StringReader(strResponse))
            {
                docx = XDocument.Load(s);
            }

            if (strResponse.Contains("Error"))
            {
                try
                {
                    ErrorMessage = docx.Element("AddressValidateResponse").Element("Address").Element("Error").Element("Description").Value;
                }
                catch
                { }
                isValid = false;
            }

            if (isValid)
            {
                USPSAddress = docx.Element("AddressValidateResponse").Element("Address").Element("Address2").Value;
                if (strResponse.Contains("Address1"))
                {
                    USPSAddress = USPSAddress + " " + docx.Element("AddressValidateResponse").Element("Address").Element("Address1").Value;
                }
                USPSCity = docx.Element("AddressValidateResponse").Element("Address").Element("City").Value;
                USPSState = docx.Element("AddressValidateResponse").Element("Address").Element("State").Value;
                USPSZip5 = docx.Element("AddressValidateResponse").Element("Address").Element("Zip5").Value;
                USPSZip4 = docx.Element("AddressValidateResponse").Element("Address").Element("Zip4").Value;
            }


            return isValid;
            //}
            //catch(Exception ex)
            //{
            //    string msg = ex.Message;
            //    return false;
            //}
        }


        private string GetDataFromSite(string USPS_Request)
        {

            try
            {
                System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                WebClient wsClient = new WebClient();
                Uri uri = new Uri(USPS_Request, UriKind.Absolute);

                string strResponse = "";

                byte[] ResponseData = wsClient.DownloadData(uri);

                foreach (byte oItem in ResponseData)
                    strResponse += (char)oItem;
                return strResponse;
            }
            catch
            {
                return "Error";
            }
        }


    }
}
